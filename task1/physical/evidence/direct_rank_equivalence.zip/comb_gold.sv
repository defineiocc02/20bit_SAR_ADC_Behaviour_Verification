module gold(input logic [17:0] available_mask, scan_cursor_onehot,
    input logic shuffle_i, output logic [17:0] next_mask, output logic [39:0] next_ids);
  logic [17:0] scan_select;
  logic [17:0] scan_available;
  logic [17:0] scan_selected;
  logic [4:0] scan_rank [18];
  logic [17:0] candidate_bit [5];

  assign scan_select = shuffle_i ? scan_cursor_onehot : 18'd1;

  // 资格计数与轮转起点无关，单独决定本拍能否接受请求。
  for (genvar lane = 0; lane < 18; lane++) begin : gen_scan
    localparam logic [17:0] Earlier = 18'h3ffff >> (18 - lane);
    logic [17:0] eligible_by_start;
    for (genvar start = 0; start < 18; start++) begin : gen_eligibility
      localparam int Physical = (lane + start) % 18;
      assign eligible_by_start[start] = available_mask[Physical];
    end
    assign scan_available[lane] = |(eligible_by_start & scan_select);
    assign scan_rank[lane] = 5'($countones(scan_available & Earlier));
    assign scan_selected[lane] = scan_available[lane] && (scan_rank[lane] < 5'd8);
    for (genvar bit_idx = 0; bit_idx < 5; bit_idx++) begin : gen_id_bits
      logic [17:0] bit_by_start;
      for (genvar start = 0; start < 18; start++) begin : gen_start
        localparam logic [4:0] Physical = 5'((lane + start) % 18);
        assign bit_by_start[start] = Physical[bit_idx];
      end
      assign candidate_bit[bit_idx][lane] = |(bit_by_start & scan_select);
    end
  end

  // 用同一个已缓存的一位有效游标把逻辑选择转回物理位图。
  for (genvar physical = 0; physical < 18; physical++) begin : gen_mask
    logic [17:0] selected_by_start;
    for (genvar start = 0; start < 18; start++) begin : gen_start
      localparam int Lane = (physical + 18 - start) % 18;
      assign selected_by_start[start] = scan_selected[Lane];
    end
    assign next_mask[physical] = |(selected_by_start & scan_select);
  end

  // 每个 slot 只由一个优先序对应的物理切片驱动。
  for (genvar slot = 0; slot < 8; slot++) begin : gen_slot
    logic [17:0] pick;
    for (genvar lane = 0; lane < 18; lane++) begin : gen_lane
      assign pick[lane] = scan_available[lane] && (scan_rank[lane] == 5'(slot));
    end
    for (genvar bit_idx = 0; bit_idx < 5; bit_idx++) begin : gen_bit
      assign next_ids[5*slot + bit_idx] = |(pick & candidate_bit[bit_idx]);
    end
  end

endmodule
