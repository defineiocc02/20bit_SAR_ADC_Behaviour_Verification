module gold(input logic [39:0] ids,input logic [17:0] mask,output logic valid);
  function automatic logic legal_group(input logic [39:0] ids, input logic [17:0] mask);
    logic [17:0] seen;
    logic [4:0] slice_id;
    logic legal;
    seen = '0;
    legal = 1'b1;
    for (int slot = 0; slot < 8; slot++) begin
      slice_id = ids[5*slot+:5];
      if (slice_id >= 5'd18) legal = 1'b0;
      else if (seen[slice_id]) legal = 1'b0;
      else seen[slice_id] = 1'b1;
    end
    legal_group = legal && (seen == mask);
  endfunction
 assign valid=legal_group(ids,mask);
endmodule
