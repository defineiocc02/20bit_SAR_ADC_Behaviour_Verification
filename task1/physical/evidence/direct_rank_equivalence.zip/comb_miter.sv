module comb_miter(input logic [17:0] available_mask,
                  input logic [4:0] cursor, input logic shuffle_i, output logic mismatch);
  logic [17:0] scan_cursor_onehot, gold_mask, gate_mask;
  logic [39:0] gold_ids, gate_ids;
  assign scan_cursor_onehot = 18'd1 << cursor;
  gold u_gold(available_mask,scan_cursor_onehot,shuffle_i,gold_mask,gold_ids);
  gate u_gate(available_mask,scan_cursor_onehot,shuffle_i,gate_mask,gate_ids);
  assign mismatch = (cursor < 5'd18) && ((gold_mask != gate_mask) || (gold_ids != gate_ids));
endmodule
