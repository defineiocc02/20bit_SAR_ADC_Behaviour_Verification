module legal_group_step(input logic [17:0] prior_seen, input logic [4:0] slice_id,
                        input logic [2:0] slots_processed, output logic mismatch);
  logic [17:0] seen;
  logic [17:0] next_union;
  logic legal;
  logic [4:0] n_before, n_after;
  always_comb begin
    n_before = 5'($countones(prior_seen));
    legal = (n_before == {2'b0, slots_processed});
    seen = prior_seen;
    if (slice_id >= 5'd18) legal = 1'b0;
    else if (seen[slice_id]) legal = 1'b0;
    else seen[slice_id] = 1'b1;
  end
  assign next_union = prior_seen | (18'd1 << slice_id);
  assign n_after = 5'($countones(next_union));
  assign mismatch = (n_before <= {2'b0, slots_processed})
      && ((seen != next_union)
          || (n_after > ({2'b0, slots_processed} + 5'd1))
          || (legal != (n_after == ({2'b0, slots_processed} + 5'd1))));
endmodule
