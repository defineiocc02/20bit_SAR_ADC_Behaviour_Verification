module comb_miter #(parameter int START=0, parameter int SHUFFLE=0)(
    input logic [17:0] available_mask, output logic mismatch);
  localparam logic shuffle_i = 1'(SHUFFLE);
  logic [17:0] scan_cursor_onehot, gold_mask, gate_mask;
  logic [39:0] gold_ids, gate_ids;
  assign scan_cursor_onehot = 18'd1 << START;
  gold u_gold(available_mask,scan_cursor_onehot,shuffle_i,gold_mask,gold_ids);
  gate u_gate(available_mask,scan_cursor_onehot,shuffle_i,gate_mask,gate_ids);
  assign mismatch = ((gold_mask != gate_mask) || (gold_ids != gate_ids));
endmodule
