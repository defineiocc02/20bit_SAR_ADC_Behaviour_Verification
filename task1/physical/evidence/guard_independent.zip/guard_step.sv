module guard_step(input logic [17:0] prior_seen, input logic prior_legal,
 input logic [4:0] slice_id, input logic [2:0] processed_i, output logic mismatch);
 logic legal;
 logic [17:0] seen, next_union;
 logic [4:0] prior_count, next_count, processed;
 assign processed = {2'b0,processed_i};
 assign prior_count = 5'($countones(prior_seen));
 always_comb begin
   seen = prior_seen;
   legal = prior_legal;
      if (slice_id >= 5'd18) legal = 1'b0;
      else if (seen[slice_id]) legal = 1'b0;
      else seen[slice_id] = 1'b1;
 end
 assign next_union = prior_seen | (18'd1 << slice_id);
 assign next_count = 5'($countones(next_union));
 assign mismatch = (prior_count <= processed)
     && (prior_legal == (prior_count == processed))
     && ((seen != next_union) || (next_count > processed + 5'd1)
         || (legal != (next_count == processed + 5'd1)));
endmodule
