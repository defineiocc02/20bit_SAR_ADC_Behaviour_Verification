module crossbar_equivalence(
    input logic [17:0] available_mask, selected_lanes,
    input logic [4:0] cursor,
    input logic shuffle_i,
    output logic mismatch);
  logic [4:0] binary_start;
  logic [17:0] scan_select, gold_available, gate_available, gold_mask, gate_mask;
  logic [35:0] gold_shifted;
  logic [89:0] gold_candidates, gate_candidates;

  assign binary_start = shuffle_i ? cursor : 5'd0;
  assign scan_select = shuffle_i ? (18'd1 << cursor) : 18'd1;
  assign gold_available = 18'({available_mask,available_mask} >> binary_start);
  assign gold_shifted = {18'b0, selected_lanes} << binary_start;
  assign gold_mask = gold_shifted[35:18] | gold_shifted[17:0];

  for (genvar lane=0; lane<18; lane++) begin : gen_scan
    logic [5:0] physical_sum;
    logic [17:0] eligible_by_start, selected_by_start;
    assign physical_sum = {1'b0,binary_start} + 6'(lane);
    assign gold_candidates[5*lane+:5] = (physical_sum >= 6'd18)
        ? 5'(physical_sum - 6'd18) : physical_sum[4:0];
    for (genvar start=0; start<18; start++) begin : gen_start
      assign eligible_by_start[start] = available_mask[(lane + start) % 18];
      assign selected_by_start[start] = selected_lanes[(lane + 18 - start) % 18];
    end
    assign gate_available[lane] = |(eligible_by_start & scan_select);
    assign gate_mask[lane] = |(selected_by_start & scan_select);
    for (genvar bit_idx=0; bit_idx<5; bit_idx++) begin : gen_bit
      logic [17:0] bit_by_start;
      for (genvar start=0; start<18; start++) begin : gen_phys
        localparam logic [4:0] Physical = 5'((lane + start) % 18);
        assign bit_by_start[start] = Physical[bit_idx];
      end
      assign gate_candidates[5*lane+bit_idx] = |(bit_by_start & scan_select);
    end
  end
  assign mismatch = (cursor < 5'd18) && ((gold_available != gate_available)
      || (gold_mask != gate_mask) || (gold_candidates != gate_candidates));
endmodule
