module prefix_identity(input logic [4:0] cursor, output logic mismatch);
  logic [17:0] onehot, old_prefix, new_prefix;
  assign onehot = 18'd1 << cursor;
  assign new_prefix = 18'h3ffff << (cursor + 5'd1);
  for (genvar physical=0; physical<18; physical++) begin : gen_prefix
    localparam logic [17:0] Through = 18'h3ffff >> (17 - physical);
    assign old_prefix[physical] = |(onehot & Through);
  end
  assign mismatch = (old_prefix != new_prefix);
endmodule
