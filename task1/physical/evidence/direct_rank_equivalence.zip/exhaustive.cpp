#include "Vcomb_miter.h"
#include <cstdint>
#include <cstdio>

int main() {
    Vcomb_miter dut;
    std::uint64_t checked = 0;
    for (unsigned start = 0; start < 19; ++start) {
        dut.cursor = start < 18 ? start : 0;
        dut.shuffle_i = start < 18;
        for (unsigned eligible = 0; eligible < (1u << 18); ++eligible) {
            dut.available_mask = eligible;
            dut.eval();
            if (dut.mismatch) {
                std::fprintf(stderr, "Mismatch: mode=%u cursor=%u mask=%05x\n",
                             unsigned(dut.shuffle_i), unsigned(dut.cursor), eligible);
                return 1;
            }
            ++checked;
        }
    }
    dut.final();
    std::printf("TASK1_RANK_EXHAUSTIVE_COMPLETE vectors=%llu mismatches=0\n",
                static_cast<unsigned long long>(checked));
}
