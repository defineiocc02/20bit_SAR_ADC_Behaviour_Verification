module rank_equivalence(input logic [4:0] cursor, output logic mismatch);
  logic [17:0] scan_select, start_at_or_before;
  logic [323:0] differences;
  assign scan_select = 18'd1 << cursor;
  for (genvar physical=0; physical<18; physical++) begin : gen_physical
    localparam logic [17:0] Through = 18'h3ffff >> (17 - physical);
    logic [5:0] physical_delta;
    logic [4:0] physical_lane;
    logic [17:0] earlier;
    assign start_at_or_before[physical] = |(scan_select & Through);
    assign physical_delta = 6'(physical+18) - {1'b0,cursor};
    assign physical_lane = physical_delta >= 6'd18
        ? 5'(physical_delta - 6'd18) : physical_delta[4:0];
    for (genvar other=0; other<18; other++) begin : gen_earlier
      logic [5:0] other_delta;
      logic [4:0] other_lane;
      if (other < physical) begin : gen_before
        assign earlier[other] = start_at_or_before[other] || !start_at_or_before[physical];
      end else if (other > physical) begin : gen_after
        assign earlier[other] = start_at_or_before[other] && !start_at_or_before[physical];
      end else begin : gen_self
        assign earlier[other] = 1'b0;
      end
      assign other_delta = 6'(other+18) - {1'b0,cursor};
      assign other_lane = other_delta >= 6'd18
          ? 5'(other_delta - 6'd18) : other_delta[4:0];
      assign differences[18*physical+other] = earlier[other] != (other_lane < physical_lane);
    end
  end
  assign mismatch = (cursor < 5'd18) && (|differences);
endmodule
