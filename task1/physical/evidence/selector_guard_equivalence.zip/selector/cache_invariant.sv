module cache_invariant(
    input logic [4:0] prior_cursor,
    input logic [7:0] seed_byte, advanced_byte,
    input logic reset_or_disabled, seed_commit, shuffled_accept,
    output logic mismatch);
  function automatic logic [4:0] scan_remainder(input logic [7:0] value);
    logic signed [5:0] delta;
    delta = $signed({2'b0, value[3:0]}) - $signed({1'b0, value[7:4], 1'b0});
    if (!delta[5]) scan_remainder = delta[4:0];
    else if (delta < -6'sd18) scan_remainder = 5'($unsigned(delta) + 6'd36);
    else scan_remainder = 5'($unsigned(delta) + 6'd18);
  endfunction
  logic [17:0] prior_onehot;
  logic [4:0] next_cursor;
  logic [17:0] next_onehot;
  assign prior_onehot = 18'd1 << prior_cursor;
  always_comb begin
    next_cursor = prior_cursor;
    next_onehot = prior_onehot;
    if (reset_or_disabled) begin
      next_cursor = 5'(8'h24 % 8'd18);
      next_onehot = 18'd1 << 5'(8'h24 % 8'd18);
    end else if (seed_commit) begin
      next_cursor = scan_remainder(seed_byte);
      next_onehot = 18'd1 << scan_remainder(seed_byte);
    end else if (shuffled_accept) begin
      next_cursor = scan_remainder(advanced_byte);
      next_onehot = 18'd1 << scan_remainder(advanced_byte);
    end
  end
  assign mismatch = (prior_cursor < 5'd18)
      && ((next_cursor >= 5'd18) || (next_onehot != (18'd1 << next_cursor)));
endmodule
