# 第二轮调度和守卫的独立 SAT 复核

选择器输入是当前实际 RTL 加只读观察端口。复位基例覆盖任意初始状态。一步保持允许任意满足缓存关系的当前状态和任意已定义输入，证明同步更新后缓存恰等于 LFSR 高字节 `%18` 所在的一位有效向量，并同时核对有效选择向量。守卫一步证明提取旧函数的逐槽更新分支和新函数的一位映射表达式。处理零槽时并集为空且 `legal` 为真。若处理过的槽数为 n，并集大小不超过 n，且 `legal` 等于并集大小是否为 n，下一槽保持这些性质。处理八槽后两版都要求该并集等于输入 mask。

```sh
yosys -l selector_proof.log -s selector_proof.ys
yosys -l guard_step_proof.log -s guard_step_proof.ys
yosys -l selector_mutant_proof.log -s selector_mutant_proof.ys
yosys -l guard_mutant_proof.log -s guard_mutant_proof.ys
```

前两命令退出 0。选择器负例额外旋转有效的一位游标，守卫负例将并集位数阈值 8 改为 7。两条负例命令应退出 1，原始日志含反例。独立整块守卫 miter 在另一次限时 48 秒的求解中超时，本收据以逐槽证明为依据。证明适用于同步边沿与已定义二值输入。全端口调度器可达域比较另见 `selector_guard_equivalence.zip`。物理时序和组合瞬态需各自的证据。
