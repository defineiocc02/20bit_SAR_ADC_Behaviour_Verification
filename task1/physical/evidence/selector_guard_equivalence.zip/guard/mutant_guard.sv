module gate(input logic [39:0] ids,input logic [17:0] mask, output logic valid);
  function automatic logic legal_group(input logic [39:0] ids, input logic [17:0] mask);
    logic [17:0] onehot [8];
    logic [17:0] seen;
    // 越界 ID 移位后为零；重复 ID 在并集里只留下一个位置。
    for (int slot = 0; slot < 8; slot++) begin
      onehot[slot] = 18'd1 << ids[5*slot+:5];
    end
    seen = ((onehot[0] | onehot[1]) | (onehot[2] | onehot[3]))
           | ((onehot[4] | onehot[5]) | (onehot[6] | onehot[7]));
    legal_group = ($countones(seen) == 7) && (seen == mask);
  endfunction
  assign valid=legal_group(ids,mask);
endmodule
