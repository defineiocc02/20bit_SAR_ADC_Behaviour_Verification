# 同步游标不变式的独立 SAT 复核

`candidate.sv` 是优化候选原样输入。`gate.sv` 只添加游标观察端口、由 LFSR 高字节 `%18` 直接计算的断言，以及裁去无关输出的顶层。原调度器、选择和接受条件仍参与证明。`gate_stale_cursor_mutant.sv` 只将 shuffle 成功沿的新游标计算换成旧 LFSR 值。

```sh
yosys -l audit.log -s check.ys
yosys -l negative.log -s check_negative.ys
```

第一项 SAT 查询验证任意初始状态在同步复位后都满足 `cursor == lfsr[31:24] % 18`。第二项假定该关系在任意当前状态成立，对所有已定义输入验证下一沿仍成立。时序步 1 与 2 对应更新前与更新后。原候选两项均通过。变异候选复位基例通过，保持性产生反例，工具应退出 1。原始 `negative.log` 含输入和状态的反例表。

证明范围是时钟沿采样的二值状态和新增游标缓存。全端口等价见单独归档 `selector_equivalence.zip`。物理时序、组合瞬态和跨域行为需要各自的证据。
