module gate(input logic [17:0] available_mask, scan_cursor_onehot,
    input logic shuffle_i, output logic [17:0] next_mask, output logic [39:0] next_ids);
  logic [17:0] start_at_or_before;
  logic [4:0] rank_fixed [18], rank_shuffled [18];
  logic [17:0] mask_fixed, mask_shuffled;
  logic [39:0] ids_fixed, ids_shuffled;
  logic [17:0] physical_id_bit [5];

  // 对每个物理位置直接形成环形前缀，避免轮转资格位或回转选择位图。
  for (genvar physical = 0; physical < 18; physical++) begin : gen_physical
    localparam logic [17:0] Through = 18'h3ffff >> (17 - physical);
    localparam logic [17:0] Earlier = 18'h3ffff >> (18 - physical);
    localparam logic [4:0] PhysicalId = 5'(physical);
    logic [17:0] earlier;
    assign start_at_or_before[physical] = |(scan_cursor_onehot & Through);

    for (genvar other = 0; other < 18; other++) begin : gen_earlier
      if (other < physical) begin : gen_before
        assign earlier[other] = start_at_or_before[other] || !start_at_or_before[physical];
      end else if (other > physical) begin : gen_after
        assign earlier[other] = start_at_or_before[other] && !start_at_or_before[physical];
      end else begin : gen_self
        assign earlier[other] = 1'b0;
      end
    end

    assign rank_fixed[physical] = 5'($countones(available_mask & Earlier));
    assign rank_shuffled[physical] = 5'($countones(available_mask & earlier));
    assign mask_fixed[physical] = available_mask[physical] && (rank_fixed[physical] < 5'd8);
    assign mask_shuffled[physical] = available_mask[physical] && (rank_shuffled[physical] < 5'd8);
    for (genvar bit_idx = 0; bit_idx < 5; bit_idx++) begin : gen_id_bits
      assign physical_id_bit[bit_idx][physical] = PhysicalId[bit_idx];
    end
  end

  // 每个 slot 只由环形序位相等的一个合格物理切片驱动。
  for (genvar slot = 0; slot < 8; slot++) begin : gen_output_slot
    logic [17:0] pick_fixed, pick_shuffled;
    for (genvar physical = 0; physical < 18; physical++) begin : gen_pick
      assign pick_fixed[physical] = available_mask[physical] && (rank_fixed[physical] == 5'(slot));
      assign pick_shuffled[physical] = available_mask[physical] && (rank_shuffled[physical] == 5'(slot));
    end
    for (genvar bit_idx = 0; bit_idx < 5; bit_idx++) begin : gen_bit
      assign ids_fixed[5*slot + bit_idx] = |(pick_fixed & physical_id_bit[bit_idx]);
      assign ids_shuffled[5*slot + bit_idx] = |(pick_shuffled & physical_id_bit[bit_idx]);
    end
  end

  // 两种排序并行完成，最后才应用模式位，避免模式输入穿过前缀计数。
  assign next_mask = shuffle_i ? mask_shuffled : mask_fixed;
  assign next_ids = shuffle_i ? ids_shuffled : ids_fixed;

endmodule
